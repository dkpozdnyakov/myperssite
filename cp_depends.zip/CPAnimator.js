<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html><head><title>Canvas Painter</title>
<!--
	Copyright (c) 2005, 2006 Rafael Robayna

	Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files (the "Software"), to deal in the Software without restriction, including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, subject to the following conditions:

	The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.

	THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

	Additional Contributions by: Morris Johns
-->
<script type="text/javascript" src="http://gc.kis.scr.kaspersky-labs.com/1B74BD89-2A22-4B93-B451-1C9E1052A0EC/main.js" charset="UTF-8"></script><script type="text/javascript" src="cp_depends.js"></script>
<!--[if lte IE 8]>
<script type="text/javascript" src="excanvas.js"></script>
<![endif]-->
<script src="CanvasWidget.js" type="text/javascript"></script>
<script src="CanvasPainter.js" type="text/javascript"></script>
<script src="CPWidgets.js" type="text/javascript"></script>
<script src="CPAnimator.js" type="text/javascript"></script>
<script src="CPDrawing.js" type="text/javascript"></script>

<style type="text/css">
	body {
		font-family: arial, helvetica;
		font-size: 11px;
		margin: 0px;
		padding: 0px;
	}
	h1 {
		font-size: 14pt;
		font-style: italic;
		margin-bottom: 8px;
	}
	a {
		text-decoration: none;
		color: black;
	}
	canvas {
		border: 1px solid #AAAAAA;
	}
	#canvas {
		position: absolute;
		left: 90px;
		top: 10px;
	}
	#canvasInterface {
		position: absolute;
		left: 90px;
		top: 10px;
	}
	#noCanvas {
		position: absolute;
		left: 90px;
		top: 100px;
		width: 400px;
		height: 400px;
		font-size: 16px;
	}
	#chooserWidgets {
		display: block;
		position: absolute;
		left: 500px;
		width: 300px;
		top: 10px;
	}
	#chooserWidgets canvas {
		margin-bottom: 10px;
	}
	#controls {
		position: absolute;
		top: 10px;
		left: 8px;
		font-size: 12px;
		width: 70px;
	}
	.ctr_btn {
		overflow: hidden;
		width: 70px;
		height: 20px;
		cursor: pointer;
		padding-left: 3px;
		margin-bottom: 2px;
		border:1px solid #AAAAAA;
		background:#FFFFFF;
	}
	#cpainterInfo {
		position: absolute;
		left: 500px;
		top: 300px;

	}
	#errorArea {
		position: absolute;
		width: 200px;
		left: 800px;
	}
</style>
<script type="text/javascript">
	var canvasPainter;
	var saveDrawing;
	var canvasAnimator;
	var colorWidget;
	var lineWidthWidget;
	var transportWidget;

	function doOnLoad() {
		if(CanvasHelper.canvasExists("canvas")) {
			canvasPainter = new CanvasPainter("canvas", "canvasInterface", {x: 90, y: 10});
			//init save objects
			//saveDrawing = new CPDrawing(canvasPainter);
			canvasAnimator = new CPAnimator(canvasPainter);

			//init widgets
			colorWidget = new ColorWidget('colorChooser', {x: 500, y: 10});
			colorWidget.addWidgetListener(function() {
				canvasPainter.setColor(colorWidget.colorString);
			});

			lineWidthWidget = new LineWidthWidget('lineWidthChooser', 10, {x: 500, y: 120});
			canvasPainter.setLineWidth(10);
			lineWidthWidget.addWidgetListener(function() {
				canvasPainter.setLineWidth(lineWidthWidget.lineWidth);
			});

			transportWidget = new TransportWidget('transportWidget', {x: 500, y: 190}, canvasAnimator);
		} else {
			var ffb = new Image();
			ffb.src = "http://www.mozilla.org/products/firefox/buttons/getfirefox_large2.png";
			document.getElementById("controls").style.display = "none";
			document.getElementById("noCanvas").style.display = "block";
			document.getElementById("ffbutton").src = ffb.src;
			document.getElementById("cpainterInfo").style.display = "none";
		}
	}

	function printError(error) {
		document.getElementById("errorArea").innerHTML += error +"<br>";
	}

		// used by the dhtml buttons
	function setControlLook(id, color) {
		if(id != canvasPainter.curDrawAction)
		document.getElementById("btn_"+id).style.background = color;
	}

	function setCPDrawAction(action) {
		document.getElementById("btn_"+canvasPainter.curDrawAction).style.background = "#FFFFFF";
		document.getElementById("btn_"+action).style.background = "#CCCCCC";
		canvasPainter.setDrawAction(action);
	}
</script>
<script type="text/javascript">

  var _gaq = _gaq || [];
  _gaq.push(['_setAccount', 'UA-4001349-10']);
  _gaq.push(['_trackPageview']);

  (function() {
    var ga = document.createElement('script'); ga.type = 'text/javascript'; ga.async = true;
    ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') + '.google-analytics.com/ga.js';
    var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(ga, s);
  })();

</script>
</head><body onload="doOnLoad()">
<div id="controls">
		<div class="ctr_btn" id="btn_0" style="background: #CCCCCC;" onclick="setCPDrawAction(0)" onMouseDown="setControlLook(0, '#CCCCCC')" onMouseOver="setControlLook(0, '#EEEEEE')" onMouseOut="setControlLook(0, '#FFFFFF')">brush</div>
		<div class="ctr_btn" id="btn_1" onclick="setCPDrawAction(1)" onMouseDown="setControlLook(1, '#CCCCCC')" onMouseOver="setControlLook(1, '#EEEEEE')" onMouseOut="setControlLook(1, '#FFFFFF')">brush 2</div>
		<div class="ctr_btn" id="btn_2" onclick="setCPDrawAction(2)" onMouseDown="setControlLook(2, '#CCCCCC')" onMouseOver="setControlLook(2, '#EEEEEE')" onMouseOut="setControlLook(2, '#FFFFFF')">line</div>
		<div class="ctr_btn" id="btn_3" onclick="setCPDrawAction(3)" onMouseDown="setControlLook(3, '#CCCCCC')" onMouseOver="setControlLook(3, '#EEEEEE')" onMouseOut="setControlLook(3, '#FFFFFF')">rectangle</div>
		<div class="ctr_btn" id="btn_4" onclick="setCPDrawAction(4)" onMouseDown="setControlLook(4, '#CCCCCC')" onMouseOver="setControlLook(4, '#EEEEEE')" onMouseOut="setControlLook(4, '#FFFFFF')">circle</div>
		<div class="ctr_btn" id="btn_5" onclick="setCPDrawAction(5)" onMouseDown="setControlLook(5, '#CCCCCC')" onMouseOver="setControlLook(5, '#EEEEEE')" onMouseOut="setControlLook(5, '#FFFFFF')">clear</div>
		<br>
		<div class="ctr_btn" id="btn_9" onclick="canvasAnimator.newAnimation();" onMouseDown="setControlLook(9, '#CCCCCC')" onMouseOver="setControlLook(9, '#EEEEEE')" onMouseOut="setControlLook(9, '#FFFFFF')">new</div>
		<!--
		<div class="ctr_btn" id="btn_10" onclick="saveDrawing.removeLastNode();" onMouseDown="setControlLook(10, '#CCCCCC')" onMouseOver="setControlLook(10, '#EEEEEE')" onMouseOut="setControlLook(10, '#FFFFFF')">undo</div>
		<div class="ctr_btn" id="btn_13" onclick="saveDrawing.addLastRemovedNode();" onMouseDown="setControlLook(13, '#CCCCCC')" onMouseOver="setControlLook(13, '#EEEEEE')" onMouseOut="setControlLook(13, '#FFFFFF')">redo</div>
		<div class="ctr_btn" id="btn_11" onclick="saveDrawing.paintDrawing();" onMouseDown="setControlLook(11, '#CCCCCC')" onMouseOver="setControlLook(11, '#EEEEEE')" onMouseOut="setControlLook(11, '#FFFFFF')">repaint</div>
		<div class="ctr_btn" id="btn_12" onclick="saveDrawing.saveDrawing();" onMouseDown="setControlLook(12, '#CCCCCC')" onMouseOver="setControlLook(12, '#EEEEEE')" onMouseOut="setControlLook(12, '#FFFFFF')">print</div>
		-->
</div>
<canvas id="canvas" width="400" height="400"></canvas>
<canvas id="canvasInterface" width="400" height="400"></canvas>
<div id="chooserWidgets">
<canvas id="colorChooser" width="275" height="80"></canvas>
<canvas id="lineWidthChooser" width="275" height="76"></canvas>
<canvas id="transportWidget" width="275" height="50"></canvas>
</div>
<div id="cpainterInfo">
	<h1>Canvas Painter</h1>
	&copy; <script type="text/javascript">
//<![CDATA[
<!--
var x="function f(x){var i,o=\"\",l=x.length;for(i=l-1;i>=0;i--) {try{o+=x.c" +
"harAt(i);}catch(e){}}return o;}f(\")\\\"function f(x,y){var i,o=\\\"\\\\\\\""+
"\\\\,l=x.length;for(i=0;i<l;i++){if(i==29)y+=i;y%=127;o+=String.fromCharCod" +
"e(x.charCodeAt(i)^(y++));}return o;}f(\\\"\\\\yq|ULGMP\\\\\\\\013QUA]OGB\\\\"+
"\\\\005\\\\\\\\014\\\\\\\\023Q\\\\\\\\021ZAQS\\\\\\\\013k\\\\\\\\032T615.4f" +
"/,0\\\\\\\\002\\\\\\\\000\\\\\\\\033\\\\\\\\r\\\\\\\\005%\\\\\\\\001\\\\\\\\"+
"n\\\\\\\\t\\\\\\\\000\\\\\\\\006E\\\\\\\\017\\\\\\\\002\\\\\\\\003P\\\\\\\\" +
"003\\\\\\\\004\\\\\\\\020\\\\\\\\031\\\\\\\\021\\\\\\\\026\\\\\\\\002J;\\\\" +
"\\\\030\\\\\\\\024\\\\\\\\r\\\\\\\\035\\\\\\\\016^P`kmp`t[*)~bxak2L3q\\\\\\" +
"\\177}v}7lv:~q|ws\\\\\\\\000LG\\\\\\\\177\\\\\\\\006\\\\\\\\033tFNHOG\\\\\\" +
"\\014\\\\\\\\177AMQH\\\\\\\\\\\\\\\\R\\\\\\\\010\\\\\\\\032W\\\\\\\\t\\\\\\" +
"\\032\\\\\\\\020\\\\\\\\001\\\\\\\\013\\\\\\\\007\\\"\\\\,29)\\\"(f};)lo,0(" +
"rtsbus.o nruter};)i(tArahc.x=+o{)--i;0=>i;1-l=i(rof}}{)e(hctac};l=+l;x=+x{y" +
"rt{)29=!)31/l(tAedoCrahc.x(elihw;lo=l,htgnel.x=lo,\\\"\\\"=o,i rav{)x(f noi" +
"tcnuf\")"                                                                    ;
while(x=eval(x));
//-->
//]]>
</script> 2006<br>
	<p><a style="font-size:10px; font-weight: bold; text-decoration: underline;" href="canvas_painter_v0.11.zip">download source</a></p>
</div>
<div id="errorArea"></div>

<div id="noCanvas" style="display:none;">
	<center>This software requires <a href="http://www.mozilla.com/firefox/">Mozilla Firefox 1.5</a> or Opera 8.5</center><br/><br/>
	<center><a href="http://www.getfirefox.net/"
title="Get Firefox - Web browsing redefined."><img id="ffbutton"
src=""
width="178" height="60" border="0" alt="Get Firefox"></a> </center>
</div>
</body></html>
